@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">

                @if (Session::has('message'))
                    <div class="alert alert-{{ Session::get('code') }}">
                        <p>{{ Session::get('message') }}</p>
                    </div>
                @endif

                <div class="panel panel-default">
                    <div class="panel-heading">Express checkout</div>
                    <div class="panel-body">
                        Pay $20 via:
                        <a href="{{ route('paypal.express-checkout') }}" class='btn-info btn'>PayPal</a>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading">Recurring payments</div>
                    <div class="panel-body">
                        Pay $20/month:
                        <a href="{{ route('paypal.express-checkout', ['recurring' => true]) }}" class='btn-info btn'>PayPal</a>
                    </div>

                    <body>
                    <h1>באיזו עמדה תרצה להשתבץ?</h1>
                    <a href="{{ action("StationShiftController@edit", "1") }}" class="btn btn-info" role="button"> 1</a>
                    <a href="{{ action("StationShiftController@edit", "2") }}" class="btn btn-info" role="button"> 2</a>
                    <a href="{{ action("StationShiftController@edit", "3") }}" class="btn btn-info" role="button"> 3</a>

                    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
                    @include('sweet::alert')
                    </body>
                </div>

            </div>
        </div>
    </div>
@endsection