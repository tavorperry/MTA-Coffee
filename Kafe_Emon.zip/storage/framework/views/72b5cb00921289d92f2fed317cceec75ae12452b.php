<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Welcome</title>
    </head>
    <body>
        <?php if(Auth::user()): ?>
        <div>
            <h1>Welcome, <?php echo e(Auth::user()->first_name); ?></h1>
            <a href="<?php echo e(route('logout')); ?>">Logout</a>
        </div>
        <?php else: ?>
        <div>
            <h1>Welcome to MTAcoffee!</h1>
            <a href="<?php echo e(route('login')); ?>">Login</a>
        </div>
        <?php endif; ?>
    </body>
</html>
