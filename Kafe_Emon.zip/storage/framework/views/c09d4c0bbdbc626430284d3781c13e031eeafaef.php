<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">

                <?php if(Session::has('message')): ?>
                    <div class="alert alert-<?php echo e(Session::get('code')); ?>">
                        <p><?php echo e(Session::get('message')); ?></p>
                    </div>
                <?php endif; ?>

                <div class="panel panel-default">
                    <div class="panel-heading">Express checkout</div>
                    <div class="panel-body">
                        Pay $20 via:
                        <a href="<?php echo e(route('paypal.express-checkout')); ?>" class='btn-info btn'>PayPal</a>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading">Recurring payments</div>
                    <div class="panel-body">
                        Pay $20/month:
                        <a href="<?php echo e(route('paypal.express-checkout', ['recurring' => true])); ?>" class='btn-info btn'>PayPal</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>