<html dir="rtl">
    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <title></title>
        <style>
            table {
                /*border: 2px solid black;*/
            }
            th, td {
                /*border: 1px solid black;*/
                /*padding: 5px;*/
                text-align: center;
            }
            input[type='checkbox']{
                zoom: 2;
            }
        </style>
    </head>
    <body>
        <h1>עדכן משמרות</h1>
        <h4>
            <?php if($station->id == 1): ?>
                <?php echo e("פומנטו"); ?>

            <?php elseif($station->id == 2): ?>
                <?php echo e("ווסטון"); ?>

            <?php else: ?>
                <?php echo e("כלכלה"); ?>

            <?php endif; ?>
        </h4>
        <form action="<?php echo e(route('station.shifts', $station->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th>משמרת</th>
                        <th>ראשון</th>
                        <th>שני</th>
                        <th>שלישי</th>
                        <th>רביעי</th>
                        <th>חמישי</th>
                    </tr>
                    <tr>
                        <th>בוקר 8:00-14:00<br></th>
                        <?php $__currentLoopData = $station->shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><input type="checkbox" name="shifts[]" value="<?php echo e($shift->id); ?>"
                                        <?php echo e(\App\Http\Controllers\StationShiftController::isUserCheckThisShiftAlready($shift)); ?>

                                >
                            </td>
                            <?php if($loop->index == 4) break; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <tr>
                        <th>ערב 14:00-20:00<br></th>
                        <?php for($i=5; $i < 10; $i++): ?>
                            <td><input type="checkbox" name="shifts[]" value="<?php echo e($station->shifts[$i]->id); ?>"
                                        <?php echo e(\App\Http\Controllers\StationShiftController::isUserCheckThisShiftAlready( $station->shifts[$i])); ?>

                                >
                            </td>
                        <?php endfor; ?>
                    </tr>
                </table><br>
            </div>
            <button type='submit'>עדכן משמרות</button>
        </form>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
        <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>