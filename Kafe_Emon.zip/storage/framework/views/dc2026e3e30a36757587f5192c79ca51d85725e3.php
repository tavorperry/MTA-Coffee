<!DOCTYPE html>
<html>
<title>Index</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../../public/css/index.css">
<?php echo e(HTML::style('css/index.css')); ?>


<body>
<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-purple w3-card" id="myNavbar">
    <a href="#home" class="right-align w3-bar-item w3-button w3-wide"> קפה אמון <img src="images/logo1.png" width="40"></a>

    <!-- Right-sided navbar links -->
    <div class="w3-left w3-hide-small">
      <a href="#about" class="w3-bar-item w3-button">ABOUT</a>
      <a href="#team" class="w3-bar-item w3-button"><i class="fa fa-user"></i> TEAM</a>
      <a href="#work" class="w3-bar-item w3-button"><i class="fa fa-th"></i> WORK</a>
      <a href="#pricing" class="w3-bar-item w3-button"><i class="fa fa-usd"></i> PRICING</a>
      <a href="#contact" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> CONTACT</a>
    </div>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-left w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<!-- Sidebar on small screens when clicking the menu icon -->
<nav class="w3-sidebar w3-bar-block w3-purple w3-card w3-animate-right w3-hide-medium w3-hide-large" style="display:none;right:0;" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16 right-align">סגור ×</a>
  <a href="#about" onclick="w3_close()" class="w3-bar-item w3-button right-align">ABOUT</a>
  <a href="#team" onclick="w3_close()" class="w3-bar-item w3-button right-align">TEAM</a>
  <a href="#work" onclick="w3_close()" class="w3-bar-item w3-button right-align">WORK</a>
  <a href="#pricing" onclick="w3_close()" class="w3-bar-item w3-button right-align">PRICING</a>
  <a href="#contact" onclick="w3_close()" class="w3-bar-item w3-button right-align">CONTACT</a>
</nav>

<!-- Header with full-height image -->
<main class="bgimg-1 w3-display-container w3-grayscale-min" id="home">
  <div class="w3-display-topright w3-text-white w3-right-aligns right-align" style="padding:10%">
    <span class="w3-jumbo w3-hide-small ">קפה אמון!</span><br>
    <span class="w3-xxlarge w3-hide-large w3-hide-medium">ברוכים הבאים לאפליקציה הרשמית של קפה אמון!</span><br>
   <!--  <span class="w3-large">Stop  valuable time with projects that just isn't you.</span> -->

    <p><a href="<?php echo e(route('paypal')); ?>" class="w3-button w3-white w3-padding-large w3-large w3-margin-top w3-opacity w3-hover-opacity-off">לחץ כאן לתשלום</a></p>
    <p><a href="<?php echo e(route('reports.create')); ?>" class="w3-button w3-white w3-padding-large w3-large w3-margin-top w3-opacity w3-hover-opacity-off">לחץ כאן לדיווח</a></p>
    <p><a href="<?php echo e(route('station')); ?>" class="w3-button w3-white w3-padding-large w3-large w3-margin-top w3-opacity w3-hover-opacity-off">לחץ כאן לשיבוץ למשמרות</a></p>
    
    <div>
      <?php if(Auth::user()): ?>
        <div>
          <h1>ברוך הבא, <?php echo e(Auth::user()->first_name); ?></h1>
          <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit">LOGOUT</button>
          </form>

        </div>
      <?php else: ?>
        <div>
          <a href="<?php echo e(route('login.google')); ?>">GOOGLE לחץ כאן להתחברות</a><br>
          <a href="<?php echo e(route('login')); ?>">לחץ כאן להתחברות</a><br>
          <a href="<?php echo e(route('register')); ?>">לחץ כאן להרשמה</a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</main>
  <div class="w3-display-bottomleft w3-text-grey w3-large" style="padding:24px 48px">
    <i class="fa fa-facebook-official w3-hover-opacity"></i>
    <i class="fa fa-instagram w3-hover-opacity"></i>
    <i class="fa fa-snapchat w3-hover-opacity"></i>
    <i class="fa fa-pinterest-p w3-hover-opacity"></i>
    <i class="fa fa-twitter w3-hover-opacity"></i>
    <i class="fa fa-linkedin w3-hover-opacity"></i>
  </div>


<!-- Add Google Maps -->
<script>
/*
function myMap()
{
  myCenter=new google.maps.LatLng(41.878114, -87.629798);
  var mapOptions= {
    center:myCenter,
    zoom:12, scrollwheel: false, draggable: false,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  var map=new google.maps.Map(document.getElementById("googleMap"),mapOptions);

  var marker = new google.maps.Marker({
    position: myCenter,
  });
  marker.setMap(map);
}
*/

/*
// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

*/

// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function w3_open() {
    if (mySidebar.style.display === 'block') {
        mySidebar.style.display = 'none';
    } else {
        mySidebar.style.display = 'block';
    }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
}
</script>

<!--
To use this code on your website, get a free API key from Google.
Read more at: https://www.w3schools.com/graphics/google_maps_basic.asp
-->

</body>
</html>
